#-*-coding:utf-8-*-
#/usr/bin/env python
#open(文件名,模式)
#默认只读模式
# f = open('ha.log')
# data = f.read()
# f.close()
# print(data)
#只读模式
# f = open('ha.log','r')
# f.write('dad')
# f.close()
#只写模式,不可读,如果文件不存在,创建新文件.文件存在,原内容清空
# f = open('ha1.log','w')
# f.write("1234")
# f.close()
#x模式只写模式,不可读,如果文件不存在,创建新文件.文件存在,报错
# f = open('ha1.log','x')
# f.write("1234")
# f.close()
#追加模式,不可读,不存在,创建文件,存在,追加到文件末尾
# f = open('ha1.log','a')
# f.write("12346")
# f.close()
#
# f = open('ha1.log','a')
# data = f.read()
# f.close()
# print(data)
# Traceback (most recent call last):
#   File "/Users/northstar/PythonData/MY_Test/training/day4/File.py", line 27, in <module>
#     data = f.read()
# io.UnsupportedOperation: not readable

#py3以字节方式打开,rb
# f = open("ha.log",'rb')
# data = f.read()
# f.close()
# print(data)
# print(type(data))

#一二进制方式只写
f = open("ha1.log",'wb')
f.write(bytes("周六",encoding="utf-8"))
f.close()
