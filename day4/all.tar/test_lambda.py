#-*-coding:utf-8-*-
#/usr/bin/env python

# def f1():
#     return 123
# r1 = f1()
#
# f2 = lambda : 123
# r2 = f2()
#
# print r1
# print r2
#
# def f3(a1,a2):
#     return a1 + a2
#
# f4 = lambda a1,a2:a1+a2
#
# r3 = f3(4,5)
# r4 = f4(5,6)
#
# print r3
# print r4

# print(reduce(lambda x,y:x*y,range(10)))