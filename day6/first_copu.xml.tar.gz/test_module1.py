#-*-coding:utf-8-*-
#/usr/bin/env python
__author__ = "Allan"
#print(vars())
'''
    这里面写该文件的注释
'''
print(__doc__)
print(__file__)

from lib import comments
print(comments.__package__)

print(comments.__cached__)

print(__name__)
print(comments.__name__)